package com.group1.fmobile.domain;

public enum RoleType {
    USER,
    ADMIN,
    GUEST,

}
