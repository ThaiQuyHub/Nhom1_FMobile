package com.group1.fmobile.controller.guest;

import com.group1.fmobile.domain.Product;
import com.group1.fmobile.service.ProductServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Controller
public class SearchPageController {
    @Autowired
    public SearchPageController(ProductServices productServices){
        this.productServices = productServices;
    }

    private final ProductServices productServices;

    @GetMapping("/search")
    public String search(@RequestParam("query") String query, Model model) {

        if (query == null || query.trim().isEmpty()) {
            return "guest/searchPage/noDataFound";
        }

        List<Product> results = productServices.searchByQuery(query.trim());
        if (results.isEmpty()) {
            return "guest/searchPage/noDataFound";
        }

        Map<String, Integer> categoryCounts = productServices.countProductsByCategory(results);
        model.addAttribute("query", query);
        model.addAttribute("categoryCounts", categoryCounts);
        model.addAttribute("products", results);

        return productServices.determineViewName(categoryCounts.keySet());
    }
}
