package com.group1.fmobile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class FMobileApplication {


	public static void main(String[] args) {
		SpringApplication.run(FMobileApplication.class, args);
	}

}
