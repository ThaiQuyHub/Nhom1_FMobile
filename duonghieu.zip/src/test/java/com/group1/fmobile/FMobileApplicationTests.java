package com.group1.fmobile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FmobileApplicationTests {

	@Test
	void contextLoads() {
	}

}
